import os
from datetime import date, datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import io, csv

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///pharmacy.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

class User(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    username=db.Column(db.String(80), unique=True, nullable=False)
    password_hash=db.Column(db.String(255), nullable=False)
    full_name=db.Column(db.String(120), nullable=False)
    role=db.Column(db.String(30), default="store")
    active=db.Column(db.Boolean, default=True)
    def set_password(self,p): self.password_hash=generate_password_hash(p)
    def check_password(self,p): return check_password_hash(self.password_hash,p)

class Medicine(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    name=db.Column(db.String(160), nullable=False)
    generic_name=db.Column(db.String(160))
    form=db.Column(db.String(80))
    strength=db.Column(db.String(80))
    company=db.Column(db.String(160))
    unit=db.Column(db.String(40), default="علبة")
    batch=db.Column(db.String(100))
    expiry=db.Column(db.Date, nullable=False)
    qty=db.Column(db.Integer, default=0)
    min_qty=db.Column(db.Integer, default=0)
    purchase_price=db.Column(db.Float, default=0)
    sale_price=db.Column(db.Float, default=0)
    location=db.Column(db.String(100))
    created_at=db.Column(db.DateTime, default=datetime.utcnow)

class Supplier(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    name=db.Column(db.String(160), nullable=False)
    phone=db.Column(db.String(60))
    address=db.Column(db.String(250))

class Department(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    name=db.Column(db.String(160), unique=True, nullable=False)

class Movement(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    medicine_id=db.Column(db.Integer, db.ForeignKey("medicine.id"), nullable=False)
    movement_type=db.Column(db.String(10), nullable=False) # in/out
    qty=db.Column(db.Integer, nullable=False)
    reference=db.Column(db.String(120))
    party=db.Column(db.String(160))
    user_id=db.Column(db.Integer, db.ForeignKey("user.id"))
    created_at=db.Column(db.DateTime, default=datetime.utcnow)
    medicine=db.relationship("Medicine")
    user=db.relationship("User")

def login_required(f):
    @wraps(f)
    def wrapper(*a,**kw):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return f(*a,**kw)
    return wrapper

def role_required(*roles):
    def deco(f):
        @wraps(f)
        def wrapper(*a,**kw):
            if not session.get("user_id"): return redirect(url_for("login"))
            if session.get("role") not in roles:
                flash("ليس لديك صلاحية لهذه العملية","danger")
                return redirect(url_for("dashboard"))
            return f(*a,**kw)
        return wrapper
    return deco

@app.context_processor
def inject():
    return {"today": date.today(), "now": datetime.now()}

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=User.query.filter_by(username=request.form["username"], active=True).first()
        if u and u.check_password(request.form["password"]):
            session.update(user_id=u.id, username=u.username, full_name=u.full_name, role=u.role)
            return redirect(url_for("dashboard"))
        flash("اسم المستخدم أو كلمة المرور غير صحيحة","danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    medicines=Medicine.query.order_by(Medicine.name).all()
    low=sum(1 for m in medicines if m.qty<=m.min_qty)
    expiring=sum(1 for m in medicines if m.expiry <= date.today()+timedelta(days=90))
    recent=Movement.query.order_by(Movement.created_at.desc()).limit(10).all()
    return render_template("dashboard.html", medicines=medicines, low=low, expiring=expiring,
                           total=len(medicines), total_qty=sum(m.qty for m in medicines), recent=recent)

@app.route("/medicines")
@login_required
def medicines():
    q=request.args.get("q","").strip()
    query=Medicine.query
    if q: query=query.filter(Medicine.name.ilike(f"%{q}%"))
    return render_template("medicines.html", medicines=query.order_by(Medicine.name).all(), q=q)

@app.route("/medicines/add", methods=["GET","POST"])
@role_required("admin","pharmacist","store")
def medicine_add():
    if request.method=="POST":
        m=Medicine(
            name=request.form["name"], generic_name=request.form.get("generic_name"),
            form=request.form.get("form"), strength=request.form.get("strength"),
            company=request.form.get("company"), unit=request.form.get("unit") or "علبة",
            batch=request.form.get("batch"), expiry=datetime.strptime(request.form["expiry"],"%Y-%m-%d").date(),
            qty=int(request.form.get("qty") or 0), min_qty=int(request.form.get("min_qty") or 0),
            purchase_price=float(request.form.get("purchase_price") or 0),
            sale_price=float(request.form.get("sale_price") or 0), location=request.form.get("location")
        )
        db.session.add(m); db.session.commit()
        flash("تمت إضافة الدواء","success"); return redirect(url_for("medicines"))
    return render_template("medicine_form.html", medicine=None)

@app.route("/medicines/<int:id>/edit", methods=["GET","POST"])
@role_required("admin","pharmacist","store")
def medicine_edit(id):
    m=Medicine.query.get_or_404(id)
    if request.method=="POST":
        for field in ["name","generic_name","form","strength","company","unit","batch","location"]:
            setattr(m,field,request.form.get(field))
        m.expiry=datetime.strptime(request.form["expiry"],"%Y-%m-%d").date()
        m.min_qty=int(request.form.get("min_qty") or 0)
        m.purchase_price=float(request.form.get("purchase_price") or 0)
        m.sale_price=float(request.form.get("sale_price") or 0)
        db.session.commit(); flash("تم تحديث الصنف","success"); return redirect(url_for("medicines"))
    return render_template("medicine_form.html", medicine=m)

@app.route("/movements/<kind>", methods=["GET","POST"])
@role_required("admin","pharmacist","store")
def movement(kind):
    if kind not in ("in","out"): return redirect(url_for("dashboard"))
    meds=Medicine.query.order_by(Medicine.name).all()
    if request.method=="POST":
        m=Medicine.query.get_or_404(int(request.form["medicine_id"]))
        qty=int(request.form["qty"])
        if qty<=0: flash("الكمية يجب أن تكون أكبر من صفر","danger"); return redirect(request.url)
        if kind=="out" and qty>m.qty:
            flash("الكمية المطلوبة أكبر من الرصيد الحالي","danger"); return redirect(request.url)
        m.qty += qty if kind=="in" else -qty
        mv=Movement(medicine=m,movement_type=kind,qty=qty,party=request.form.get("party"),
                    reference=request.form.get("reference"),user_id=session["user_id"])
        db.session.add(mv); db.session.commit()
        flash("تم تسجيل الحركة بنجاح","success"); return redirect(url_for("dashboard"))
    return render_template("movement.html", kind=kind, medicines=meds)

@app.route("/movements")
@login_required
def movements():
    rows=Movement.query.order_by(Movement.created_at.desc()).all()
    return render_template("movements.html", rows=rows)

@app.route("/suppliers", methods=["GET","POST"])
@role_required("admin","store")
def suppliers():
    if request.method=="POST":
        db.session.add(Supplier(name=request.form["name"],phone=request.form.get("phone"),address=request.form.get("address")))
        db.session.commit(); flash("تمت إضافة المورد","success")
    return render_template("suppliers.html", suppliers=Supplier.query.order_by(Supplier.name).all())

@app.route("/departments", methods=["GET","POST"])
@role_required("admin","store")
def departments():
    if request.method=="POST":
        db.session.add(Department(name=request.form["name"])); db.session.commit(); flash("تمت إضافة القسم","success")
    return render_template("departments.html", departments=Department.query.order_by(Department.name).all())

@app.route("/reports")
@login_required
def reports():
    meds=Medicine.query.order_by(Medicine.expiry).all()
    return render_template("reports.html", medicines=meds)

@app.route("/backup.csv")
@login_required
def backup_csv():
    out=io.StringIO(); w=csv.writer(out)
    w.writerow(["اسم الدواء","الشركة","التشغيلة","الكمية","الحد الأدنى","الانتهاء","الموقع"])
    for m in Medicine.query.order_by(Medicine.name).all():
        w.writerow([m.name,m.company,m.batch,m.qty,m.min_qty,m.expiry.isoformat(),m.location])
    data=io.BytesIO(out.getvalue().encode("utf-8-sig"))
    return send_file(data, mimetype="text/csv", as_attachment=True, download_name="pharmacy_backup.csv")

@app.route("/api/stats")
@login_required
def api_stats():
    meds=Medicine.query.all()
    return jsonify(total=len(meds), low=sum(m.qty<=m.min_qty for m in meds),
                   expiring=sum(m.expiry<=date.today()+timedelta(days=90) for m in meds),
                   quantity=sum(m.qty for m in meds))

def init_db():
    db.create_all()
    if not User.query.filter_by(username="admin").first():
        u=User(username="admin",full_name="مدير النظام",role="admin"); u.set_password("admin123")
        db.session.add(u)
        db.session.add_all([Department(name="الصيدلية"),Department(name="الطوارئ"),Department(name="المخزن")])
        db.session.commit()

with app.app_context(): init_db()

if __name__=="__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)), debug=False)
